import BasicTables from "../Tables/BasicTables";

export default function Verifykasi() {
  return (
    <>
     <div>
        
     </div>
    </>
  );
}
